import {Component} from '@angular/core';
import { Router } from '@angular/router';
import { ContactService } from '../../service/contact-service';
import {Page404} from '../page404/page404';

@Component({
  selector: 'app-gestion',
  imports: [
    Page404
  ],
  templateUrl: './gestion.html',
  styleUrl: './gestion.scss'
})
export class Gestion{
  public last: any;

  constructor(
    private contactService: ContactService,
    private router: Router
  ) {
    this.last = this.contactService.getContact();
    if (!this.last) {
      this.router.navigate(['/404']);
    }
  }
}
