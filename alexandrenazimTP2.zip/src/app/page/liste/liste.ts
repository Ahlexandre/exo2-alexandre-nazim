import {Component} from '@angular/core';

interface Film {
  titre: string;
  affiche: string;
}

@Component({
  selector: 'app-liste',
  imports: [],
  templateUrl: './liste.html',
  styleUrl: './liste.scss'
})
export class Liste {
  public films: Film[] = [
    {
      titre: 'Batman',
      affiche: 'assets/batman.jpg'
    },
    {
      titre: 'Batman Begins',
      affiche: 'assets/batmanbegins.jpg'
    },
    {
      titre: 'The Dark Knight : Le Chevalier noir',
      affiche: 'assets/thedarknightchevaliernoir.jpg'
    },
    {
      titre: 'The Dark Knigh Rises',
      affiche: 'assets/thedarkknightrises.jpeg'
    },
    {
      titre: 'The Batman',
      affiche: 'assets/thebatman.jpg'
    }
  ];

  public filmSelectionne: Film | null = null;

  public choisirFilm(film: Film) {
    this.filmSelectionne = film;
  }
}
