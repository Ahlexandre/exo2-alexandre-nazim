import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  private lastContact: any = null;

  public saveContact(contact: any) {
    this.lastContact = contact;
  }

  public getContact() {
    return this.lastContact;
  }
}
